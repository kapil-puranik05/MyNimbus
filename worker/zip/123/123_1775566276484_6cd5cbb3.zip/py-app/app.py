from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return "Hello from Flask! 🚀"

@app.route("/api/data")
def get_data():
    # Example of returning JSON data
    return jsonify({"status": "success", "message": "API is working"})

if __name__ == "__main__":
    # Set the port to 8080 or 3000 to match your Cloudflare config
    app.run(host="0.0.0.0", port=8080, debug=True)

